gmod-module-base
================

Technically everything you need is in include.
